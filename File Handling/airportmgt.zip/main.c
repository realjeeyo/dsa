#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "flight.h"

void main(){
    Flight list[MAX];
    Destination NAIA = newDest("NAIA",1);
    Destination Clark = newDest("Clark Airport",2);
    Destination Francisco = newDest("Francisco Airport",2);
    Destination Iloilo = newDest("Iloilo Airport",2);
    Destination Panglao = newDest("Panglao Airport",3);
    Destination Bicol = newDest("Bicol Airport",4);
    Destination Bantayan = newDest("Bantayan AP",5);
    Destination Alto = newDest("Alto Airfield",6);
    
    list[0] = newFlight(201,"PAL",newSched(30,10),NAIA);
    list[1] = newFlight(202,"CebuPac",newSched(30,10),Clark);
    list[2] = newFlight(203,"PAL",newSched(30,12),Francisco);
    list[3] = newFlight(204,"SG",newSched(30,5),Iloilo);
    list[4] = newFlight(205,"Boieng",newSched(45,6),Panglao);
    list[5] = newFlight(206,"PAL",newSched(30,6),Bicol);
    list[6] = newFlight(207,"CebuPac",newSched(10,15),Bantayan);
    list[7] = newFlight(208,"Emirates",newSched(10,15),NAIA);
    list[8] = newFlight(209,"PAL",newSched(20,22),NAIA);
    
    FILE *fp;
    
    fp = fopen("destination_file.dat","wb");
    if (fp != NULL){
        fwrite(flightList,sizeof(Flight),9,fp);
    }
    fclose(fp);
    
    PriorityQueue flights;
    
    Flight p;
    fp = fopen("destination_file.dat","rb");
    if (fp != NULL){
        while (fread(&p, sizeof(Flight),1,fp)){
            insertFlight(&flights,p);
        }
    }

    
    display(flights);
    fclose(fp);
    
    PriorityQueue new;
    new.count = 0;
    flightsBefore(&flights,flightList[6], &new);
    display(new);
}